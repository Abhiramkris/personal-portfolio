<script language="JavaScript">

var nl = getNewLine()

function getNewLine() {
	var agent = navigator.userAgent

	if (agent.indexOf("Win") >= 0)
		return "\r\n"
	else
		if (agent.indexOf("Mac") >= 0)
			return "\r"

 	return "\r"

}

pagecode = '#include <stdio.h>
int main()
{
      printf("from crypt import methods
from unittest import expectedFailure
import mariadb
from flask import Flask,render_template,request
from markupsafe import re
from forms import UserForm
import os
SECRET_KEY = os.urandom(32)

import sys
try:
    conn=mariadb.connect(
        user=\\"kamal\\",
        password=\\"k1\\",
        host=\'localhost\',
        database=\'test1\'
    )
except mariadb.Error as e:
    print(e)
    sys.exit(1) 

cur=conn.cursor()
#cur.execute(\\"Select *from table1\\")
#for(x,y) in cur:
 #   print(x,y)

app = Flask(__name__)
app.config[\'SECRET_KEY\'] = SECRET_KEY
@app.route(\\"/\\")
def hello_world():
    data=\'a\'
    return render_template(\'base.html\',data=data)

@app.route(\\"/aaahhh\\", methods=[\'GET\',\'POST\'])
def frms():
     form = UserForm()
     if request.method==\'POST\':
         x1,x2,y1,y2=request.form[\'x1\'],request.form[\'x2\'],request.form[\'y1\'],request.form[\'y2\']
         print(x1)
         sql=\\"insert into table1 (x,y) values (\\"+x1+\\", 6)\\"
         val=x1
         print(sql)
         cur=conn.cursor()
         cur.execute(sql,val)
         conn.commit()
         return render_template(\'base.html\', form=form, x1=x1)
     else:
        return render_template(\'base.html\', form=form)
if __name__ == \'__main__\':
    app.run(debug=True, host=\'0.0.0.0\')\\n");
      return 0;
}'

document.write(pagecode);

</script>